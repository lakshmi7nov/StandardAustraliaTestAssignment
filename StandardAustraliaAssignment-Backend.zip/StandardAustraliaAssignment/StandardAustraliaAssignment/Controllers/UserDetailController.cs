﻿using Microsoft.AspNetCore.Mvc;
using StandardAustraliaAssignment.BusinessLogic.Interface;
using StandardAustraliaAssignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace StandardAustraliaAssignment.Controllers
{
    /// <summary>
    /// UserDetail Rest methods - GET/PUT/POST/DELETE
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UserDetailController : ControllerBase
    {
        ILoggerFactory _loggerFactory;
        private readonly IUserDetailBL _userDetailBL;
        public UserDetailController(IUserDetailBL userDetailBL, ILoggerFactory loggerFactory)
        {
            _userDetailBL = userDetailBL;
            _loggerFactory = loggerFactory;
        }

        [HttpGet]
        public async Task<IEnumerable<UserDetail>> Get()
        {
            Task<IEnumerable<UserDetail>> userDetails = null;
            try
            {
                userDetails = _userDetailBL.GetUserDetails();
            }
            catch (Exception ex)
            {
                var logger = _loggerFactory.CreateLogger("LoggerCategory");
                logger.LogError($"Exception in Get: {ex}");
            }
            return await userDetails;
        }

        [HttpGet("getUserDetail/{userId}")]
        public async Task<UserDetail> Get(string userId)
        {
            Task<UserDetail> userDetail = null;
            try
            {
                userDetail = _userDetailBL.GetUserDetail(userId);
            }
            catch (Exception ex)
            {
                var logger = _loggerFactory.CreateLogger("LoggerCategory");
                logger.LogError($"Exception in GetbyId: {ex}");
            }
            return await userDetail;

        }


        [HttpPost]
        public async void Post(UserDetail userDetail)
        {
            try
            {
                await _userDetailBL.AddUserDetail(userDetail);
            }
            catch (Exception ex)
            {
                var logger = _loggerFactory.CreateLogger("LoggerCategory");
                logger.LogError($"Exception in Post: {ex}");
            }
        }

        [HttpPut]
        public async void Put(string userId, UserDetail userDetail)
        {
            try
            {
                await _userDetailBL.UpdateUserDetail(userId, userDetail);
            }
            catch (Exception ex)
            {
                var logger = _loggerFactory.CreateLogger("LoggerCategory");
                logger.LogError($"Exception in Put: {ex}");
            }
        }

        [HttpDelete]
        public async void Delete(string userId)
        {
            try
            {
                await _userDetailBL.DeleteUserDetail(userId);
            }
            catch (Exception ex)
            {
                var logger = _loggerFactory.CreateLogger("LoggerCategory");
                logger.LogError($"Exception in Delete: {ex}");
            }
        }
    }
}
