﻿using StandardAustraliaAssignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StandardAustraliaAssignment.BusinessLogic.Interface
{
    public interface IUserDetailBL
    {
        Task<IEnumerable<UserDetail>> GetUserDetails();

        Task AddUserDetail(UserDetail userDetail);

        Task UpdateUserDetail(string userId, UserDetail userDetail);

        Task DeleteUserDetail(string id);

        Task<UserDetail> GetUserDetail(string userId);
        
    }
}
