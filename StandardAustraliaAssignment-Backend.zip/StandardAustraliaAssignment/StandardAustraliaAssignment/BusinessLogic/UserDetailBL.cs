﻿using StandardAustraliaAssignment.BusinessLogic.Interface;
using StandardAustraliaAssignment.DataAccess.Interface;
using StandardAustraliaAssignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StandardAustraliaAssignment.BusinessLogic
{
    public class UserDetailBL: IUserDetailBL
    {
        private readonly IUserDetailDL _userDetailDL;
        public UserDetailBL(IUserDetailDL userDetailDL)
        {
            _userDetailDL = userDetailDL;
        }

        public async Task<IEnumerable<UserDetail>> GetUserDetails()
        {
            return await _userDetailDL.GetUserDetails();
        }

        public async Task<UserDetail> GetUserDetail(string userId)
        {
            return await _userDetailDL.GetUserDetail(userId);
        }

        public async Task AddUserDetail(UserDetail userDetail)
        {
            await _userDetailDL.AddUserDetail(userDetail);
        }

        public async Task UpdateUserDetail(string userId, UserDetail userDetail)
        {
            await _userDetailDL.UpdateUserDetail(userId, userDetail);
        }

        public async Task DeleteUserDetail(string userId)
        {
            await _userDetailDL.DeleteUserDetail(userId);
        }
    }
}
