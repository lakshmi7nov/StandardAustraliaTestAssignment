﻿using StandardAustraliaAssignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StandardAustraliaAssignment.DataAccess.Interface
{
    public interface IUserDetailDL
    {
        Task<IEnumerable<UserDetail>> GetUserDetails();

        Task<UserDetail> GetUserDetail(string userId);
        

        Task AddUserDetail(UserDetail userDetail);

        Task UpdateUserDetail(string userId, UserDetail userDetail);

        Task DeleteUserDetail(string id);

 
    }
}
