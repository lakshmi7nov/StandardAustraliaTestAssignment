﻿using Newtonsoft.Json;
using StandardAustraliaAssignment.DataAccess.Interface;
using StandardAustraliaAssignment.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace StandardAustraliaAssignment.DataAccess
{
    /// <summary>
    /// DAL layer interacting with JSON file
    /// </summary>
    public class UserDetailDL : IUserDetailDL
    {
        /// <summary>
        /// function to get UserDetails
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<UserDetail>> GetUserDetails()
        {
            return await LoadJson();
        }
        
        /// <summary>
        /// function to add new record for User
        /// </summary>
        /// <param name="userDetail"></param>
        /// <returns></returns>
        public async Task AddUserDetail(UserDetail userDetail)
        {
            try
            {
                await Task.Run(() =>
                {
                    var userDetails = ((List<UserDetail>)LoadJson().Result);
                    int maxId = 0;

                    if (userDetails != null)
                    maxId = userDetails.OrderByDescending(userDetail => userDetail.Id).FirstOrDefault().Id;

                    userDetail.Id = maxId + 1;

                    userDetails.Add(userDetail);

                    string newJsonResult = JsonConvert.SerializeObject(userDetails, Formatting.Indented);
                    File.WriteAllText("MOCK_DATA.json", newJsonResult);
                });

            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// function to update user detail
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userDetail"></param>
        /// <returns></returns>
        public async Task UpdateUserDetail(string userId, UserDetail userDetail)
        {
            try
            {
                await Task.Run(() =>
                {
                    var userDetails = ((List<UserDetail>)LoadJson().Result);
                    UserDetail userToUpdate = userDetails.FirstOrDefault(obj => obj.Id == Convert.ToInt32(userId));

                    if (userToUpdate != null)
                    {
                        userToUpdate.FirstName = userDetail.FirstName;
                        userToUpdate.LastName = userDetail.LastName;
                        userToUpdate.Email = userDetail.Email;
                        userToUpdate.Status = userDetail.Status;
                        userToUpdate.Gender = userDetail.Gender;
                    }

                    string newJsonResult = JsonConvert.SerializeObject(userDetails, Formatting.Indented);
                    File.WriteAllText("MOCK_DATA.json", newJsonResult);
                });
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// function to delete user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task DeleteUserDetail(string userId)
        {
            try
            {
                await Task.Run(() =>
                {
                    if (Convert.ToInt32(userId) > 0)
                    {
                        var userDetails = ((List<UserDetail>)LoadJson().Result);
                        var userToDelete = userDetails.FirstOrDefault(obj => obj.Id == Convert.ToInt32(userId));
                        
                        if (userToDelete != null)
                        userDetails.Remove(userToDelete);

                        string newJsonResult = JsonConvert.SerializeObject(userDetails, Formatting.Indented);
                        File.WriteAllText("MOCK_DATA.json", newJsonResult);
                    }
                });
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// function to get user detail for a particular userId
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<UserDetail> GetUserDetail(string userId)
        {
            try
            {
                UserDetail userDetail = null;
                await Task.Run(() =>
                {
                    if (Convert.ToInt32(userId) > 0)
                    {
                        var userDetails = ((List<UserDetail>)LoadJson().Result);
                        userDetail = userDetails.FirstOrDefault(obj => obj.Id == Convert.ToInt32(userId));
                    }
                });
                return userDetail;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// function to read data from json file
        /// </summary>
        /// <returns></returns>
        private async Task<IEnumerable<UserDetail>> LoadJson()
        {
            try
            {
                return await DeserializeObjectDetails(GetJsonStringFromFile());
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// function to read json data from mock json file
        /// </summary>
        /// <returns></returns>
        private async Task<string> GetJsonStringFromFile()
        {
            try
            {
                string json = string.Empty;
                await Task.Run(() =>
                {
                    using (StreamReader r = new StreamReader("MOCK_DATA.json"))
                    {
                        json = r.ReadToEnd();
                    }
                });

                return json;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// function to deserialize json result into Userdetail object
        /// </summary>
        /// <param name="json"></param>
        /// <returns></returns>
        private async Task<IEnumerable<UserDetail>> DeserializeObjectDetails(Task<string> json)
        {
            try
            {
                List<UserDetail> items = null;
                await Task.Run(() =>
                {
                    items = JsonConvert.DeserializeObject<List<UserDetail>>(json.Result);
                });
                return items;

            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}